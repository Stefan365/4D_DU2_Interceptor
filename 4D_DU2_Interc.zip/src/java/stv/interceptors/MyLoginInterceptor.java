/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stv.interceptors;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import java.util.Map;

/**
 *
 * @author User
 */
public class MyLoginInterceptor extends AbstractInterceptor {

    /**
     *
     * @param ai
     * @return
     * @throws java.lang.Exception
     */
    @Override
    public String intercept(ActionInvocation ai) throws Exception {

        System.out.println("YYYYYYYYYYYYYYY:");

        ActionContext actionContext = ai.getInvocationContext();
        Map<String, Object> session = actionContext.getSession();
        String action = ai.getInvocationContext().getName();

        String log = (String) session.get("login");
        String pw = (String) session.get("password");

        if ("myLogin".equals(action) || "myLogout".equals(action)) {
            return ai.invoke();
        } else {
            if ("Karel".equals(log) && "test".equals(pw)) {
                String str = ai.invoke();
                System.out.println("ANO, je to tak:*" + action + "*" + str + "*");
                return ai.invoke();

            } else {
                String str = Action.INPUT;//ai.invoke();
                System.out.println("NIE, je to tak:*" + action + "*" + str + "*");
                //return str;
                return "input";//Action.INPUT;   
                //return "gohome";//Action.INPUT;   
                
            }
        }
    }
}
